dPath = 'data/'
dataPath = paste0(dPath, "data/")
resultsPath = paste0(dPath, 'rdaResults/')
graphicsPath = paste0(dPath, 'summResults/')

gPath = 'netModels/'
funcPath = paste0(gPath, 'code/helpers/')