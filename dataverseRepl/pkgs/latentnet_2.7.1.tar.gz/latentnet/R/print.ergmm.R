print.ergmm<-show.ergmm<-function(x,...){
cat("Fitted ERGMM model:\n")
print(x$model)
}
