latent <- function(...){
    cat("The central function in the 'latentnet' package is 'ergmm'\n")
    cat('Type help(package="latentnet") to get started.\n')
}
latentcluster <- function(...){
    cat("The central function in the 'latentnet' package is 'ergmm'\n")
    cat('Type help(package="latentnet") to get started.\n')
}
